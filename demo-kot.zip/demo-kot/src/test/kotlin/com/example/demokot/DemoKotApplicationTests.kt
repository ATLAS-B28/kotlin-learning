package com.example.demokot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoKotApplicationTests {

	@Test
	fun contextLoads() {
	}

}
